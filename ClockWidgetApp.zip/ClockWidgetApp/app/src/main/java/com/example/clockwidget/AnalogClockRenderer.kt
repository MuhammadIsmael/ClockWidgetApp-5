package com.example.clockwidget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import java.util.Calendar
import kotlin.math.cos
import kotlin.math.sin

/**
 * The available analog clock face designs. Each style controls rim color, dial color,
 * numeral/hand colors, and whether a "QUARTZ" style label is shown, mirroring the
 * variety of reference photos (plain black rim, red rim, colorful dial, etc).
 */
enum class ClockStyle(val displayName: String) {
    CLASSIC_BLACK("Classic Black"),
    RED_RIM("Red Rim"),
    BLUE_MODERN("Blue Modern"),
    SUNSET_PINK("Sunset Pink"),
    MINT("Mint Green"),
    AMBER("Amber Rim");

    companion object {
        fun fromName(name: String?): ClockStyle =
            entries.firstOrNull { it.name == name } ?: CLASSIC_BLACK
    }
}

/** Which face(s) the widget shows: both side by side, or just one. */
enum class ClockType(val displayName: String) {
    BOTH("Analog + Digital"),
    ANALOG_ONLY("Analog Only"),
    DIGITAL_ONLY("Digital Only");

    companion object {
        fun fromName(name: String?): ClockType =
            entries.firstOrNull { it.name == name } ?: BOTH
    }
}

private data class FacePalette(
    val rimColor: Int,
    val dialColor: Int,
    val numeralColor: Int,
    val tickColor: Int,
    val hourHandColor: Int,
    val minuteHandColor: Int,
    val secondHandColor: Int,
    val dateWindowBg: Int,
    val dateTextColor: Int,
    val showBrandLabel: Boolean
)

/**
 * Renders an analog clock face (numerals, ticks, hands, and a date window at the
 * 3 o'clock position) in one of several selectable color styles.
 */
object AnalogClockRenderer {

    private fun paletteFor(clockStyle: ClockStyle): FacePalette = when (clockStyle) {
        ClockStyle.CLASSIC_BLACK -> FacePalette(
            rimColor = Color.BLACK,
            dialColor = Color.WHITE,
            numeralColor = Color.BLACK,
            tickColor = Color.BLACK,
            hourHandColor = Color.BLACK,
            minuteHandColor = Color.BLACK,
            secondHandColor = Color.RED,
            dateWindowBg = Color.WHITE,
            dateTextColor = Color.BLACK,
            showBrandLabel = false
        )
        ClockStyle.RED_RIM -> FacePalette(
            rimColor = Color.parseColor("#D32F2F"),
            dialColor = Color.WHITE,
            numeralColor = Color.parseColor("#1A1A1A"),
            tickColor = Color.parseColor("#1A1A1A"),
            hourHandColor = Color.parseColor("#1A1A1A"),
            minuteHandColor = Color.parseColor("#1A1A1A"),
            secondHandColor = Color.parseColor("#D32F2F"),
            dateWindowBg = Color.WHITE,
            dateTextColor = Color.parseColor("#1A1A1A"),
            showBrandLabel = true
        )
        ClockStyle.BLUE_MODERN -> FacePalette(
            rimColor = Color.parseColor("#1E5FBF"),
            dialColor = Color.WHITE,
            numeralColor = Color.parseColor("#0D1B33"),
            tickColor = Color.parseColor("#0D1B33"),
            hourHandColor = Color.parseColor("#0D1B33"),
            minuteHandColor = Color.parseColor("#0D1B33"),
            secondHandColor = Color.parseColor("#D32F2F"),
            dateWindowBg = Color.WHITE,
            dateTextColor = Color.parseColor("#0D1B33"),
            showBrandLabel = false
        )
        ClockStyle.SUNSET_PINK -> FacePalette(
            rimColor = Color.parseColor("#C2185B"),
            dialColor = Color.WHITE,
            numeralColor = Color.parseColor("#2A2A2A"),
            tickColor = Color.parseColor("#2A2A2A"),
            hourHandColor = Color.parseColor("#2A2A2A"),
            minuteHandColor = Color.parseColor("#2A2A2A"),
            secondHandColor = Color.parseColor("#C2185B"),
            dateWindowBg = Color.WHITE,
            dateTextColor = Color.parseColor("#2A2A2A"),
            showBrandLabel = false
        )
        ClockStyle.MINT -> FacePalette(
            rimColor = Color.parseColor("#00897B"),
            dialColor = Color.WHITE,
            numeralColor = Color.parseColor("#1A1A1A"),
            tickColor = Color.parseColor("#1A1A1A"),
            hourHandColor = Color.parseColor("#1A1A1A"),
            minuteHandColor = Color.parseColor("#1A1A1A"),
            secondHandColor = Color.parseColor("#00897B"),
            dateWindowBg = Color.WHITE,
            dateTextColor = Color.parseColor("#1A1A1A"),
            showBrandLabel = false
        )
        ClockStyle.AMBER -> FacePalette(
            rimColor = Color.parseColor("#FBC02D"),
            dialColor = Color.WHITE,
            numeralColor = Color.parseColor("#1A1A1A"),
            tickColor = Color.parseColor("#1A1A1A"),
            hourHandColor = Color.parseColor("#1A1A1A"),
            minuteHandColor = Color.parseColor("#1A1A1A"),
            secondHandColor = Color.parseColor("#FBC02D"),
            dateWindowBg = Color.WHITE,
            dateTextColor = Color.parseColor("#1A1A1A"),
            showBrandLabel = false
        )
    }

    fun render(size: Int, cal: Calendar, clockStyle: ClockStyle = ClockStyle.CLASSIC_BLACK): Bitmap {
        val palette = paletteFor(clockStyle)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val cx = size / 2f
        val cy = size / 2f
        val radius = size / 2f * 0.96f

        // Outer rim
        val rimPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        rimPaint.color = palette.rimColor
        rimPaint.style = Paint.Style.FILL
        canvas.drawCircle(cx, cy, radius, rimPaint)

        // Dial
        val dialRadius = radius * 0.90f
        val dialPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        dialPaint.color = palette.dialColor
        dialPaint.style = Paint.Style.FILL
        canvas.drawCircle(cx, cy, dialRadius, dialPaint)

        // Tick marks
        val tickPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        tickPaint.color = palette.tickColor
        tickPaint.strokeWidth = size * 0.006f
        for (i in 0 until 60) {
            val angle = Math.toRadians((i * 6).toDouble())
            val isHour = i % 5 == 0
            val outerR = dialRadius * 0.95f
            val innerR = if (isHour) dialRadius * 0.85f else dialRadius * 0.90f
            val x1 = cx + (outerR * sin(angle)).toFloat()
            val y1 = cy - (outerR * cos(angle)).toFloat()
            val x2 = cx + (innerR * sin(angle)).toFloat()
            val y2 = cy - (innerR * cos(angle)).toFloat()
            tickPaint.strokeWidth = if (isHour) size * 0.012f else size * 0.005f
            canvas.drawLine(x1, y1, x2, y2, tickPaint)
        }

        // Numerals 1-12
        val numPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        numPaint.color = palette.numeralColor
        numPaint.textSize = size * 0.13f
        numPaint.textAlign = Paint.Align.CENTER
        numPaint.isFakeBoldText = true
        val numRadius = dialRadius * 0.72f
        for (i in 1..12) {
            // The "3" numeral is skipped here — the date window below sits in that spot
            // (same radius as the other numerals), the way a real watch date complication
            // replaces the 3 instead of crowding next to it.
            if (i == 3) continue
            val angle = Math.toRadians((i * 30).toDouble())
            val x = cx + (numRadius * sin(angle)).toFloat()
            val fm = numPaint.fontMetrics
            val y = cy - (numRadius * cos(angle)).toFloat() - (fm.ascent + fm.descent) / 2
            canvas.drawText(i.toString(), x, y, numPaint)
        }

        // Date window at the 3 o'clock position, pushed out to sit on the numeral ring
        // (in place of the "3") rather than close to the center, so it reads as a proper
        // watch date complication and doesn't crowd the hands or the "3" numeral.
        val day = cal.get(Calendar.DAY_OF_MONTH).toString()
        val windowW = size * 0.14f
        val windowH = size * 0.11f
        val windowCx = cx + dialRadius * 0.80f
        val windowCy = cy
        val windowRect = RectF(
            windowCx - windowW / 2, windowCy - windowH / 2,
            windowCx + windowW / 2, windowCy + windowH / 2
        )
        val windowBg = Paint(Paint.ANTI_ALIAS_FLAG)
        windowBg.color = palette.dateWindowBg
        windowBg.style = Paint.Style.FILL

        val windowBorder = Paint(Paint.ANTI_ALIAS_FLAG)
        windowBorder.color = palette.numeralColor
        windowBorder.style = Paint.Style.STROKE
        windowBorder.strokeWidth = size * 0.006f

        canvas.drawRoundRect(windowRect, 6f, 6f, windowBg)
        canvas.drawRoundRect(windowRect, 6f, 6f, windowBorder)

        val datePaint = Paint(Paint.ANTI_ALIAS_FLAG)
        datePaint.color = palette.dateTextColor
        datePaint.textSize = windowH * 0.78f
        datePaint.textAlign = Paint.Align.CENTER
        datePaint.isFakeBoldText = true
        val dfm = datePaint.fontMetrics
        canvas.drawText(day, windowCx, windowCy - (dfm.ascent + dfm.descent) / 2, datePaint)

        // Optional small brand-style label under center (purely decorative, like "QUARTZ")
        if (palette.showBrandLabel) {
            val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG)
            labelPaint.color = palette.numeralColor
            labelPaint.textSize = size * 0.035f
            labelPaint.textAlign = Paint.Align.CENTER
            labelPaint.isFakeBoldText = true
            labelPaint.alpha = 180
            canvas.drawText("QUARTZ", cx, cy + dialRadius * 0.42f, labelPaint)
        }

        // Hands. The second hand uses fractional seconds (milliseconds included) so that,
        // combined with a faster tick rate in the provider, it sweeps smoothly instead of
        // visibly jumping once a second.
        val hour = cal.get(Calendar.HOUR)
        val minute = cal.get(Calendar.MINUTE)
        val second = cal.get(Calendar.SECOND)
        val millis = cal.get(Calendar.MILLISECOND)
        val fractionalSecond = second + millis / 1000.0

        val hourAngle = Math.toRadians(((hour % 12) * 30 + minute * 0.5).toDouble())
        val minuteAngle = Math.toRadians((minute * 6 + second * 0.1).toDouble())
        val secondAngle = Math.toRadians((fractionalSecond * 6).toDouble())

        drawHand(canvas, cx, cy, hourAngle, dialRadius * 0.5f, size * 0.022f, palette.hourHandColor)
        drawHand(canvas, cx, cy, minuteAngle, dialRadius * 0.72f, size * 0.016f, palette.minuteHandColor)
        drawHand(canvas, cx, cy, secondAngle, dialRadius * 0.80f, size * 0.006f, palette.secondHandColor, tailFraction = 0.18f)

        // Center pin
        val pinPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        pinPaint.color = palette.secondHandColor
        canvas.drawCircle(cx, cy, size * 0.018f, pinPaint)

        val pinOutline = Paint(Paint.ANTI_ALIAS_FLAG)
        pinOutline.color = palette.numeralColor
        pinOutline.style = Paint.Style.STROKE
        pinOutline.strokeWidth = size * 0.004f
        canvas.drawCircle(cx, cy, size * 0.018f, pinOutline)

        return bmp
    }

    /** Small preview swatch used in the style picker (no date/hands detail needed at tiny size). */
    fun renderPreview(size: Int, clockStyle: ClockStyle): Bitmap =
        render(size, Calendar.getInstance(), clockStyle)

    private fun drawHand(
        canvas: Canvas, cx: Float, cy: Float, angle: Double,
        length: Float, width: Float, color: Int, tailFraction: Float = 0f
    ) {
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.color = color
        paint.strokeWidth = width
        paint.strokeCap = Paint.Cap.ROUND
        val tipX = cx + (length * sin(angle)).toFloat()
        val tipY = cy - (length * cos(angle)).toFloat()
        canvas.drawLine(cx, cy, tipX, tipY, paint)
        if (tailFraction > 0f) {
            val tailX = cx - (length * tailFraction * sin(angle)).toFloat()
            val tailY = cy + (length * tailFraction * cos(angle)).toFloat()
            canvas.drawLine(cx, cy, tailX, tailY, paint)
        }
    }
}
