package com.example.clockwidget

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * Implements Samsung's UNOFFICIAL, undocumented "Face Widget" mechanism, which is what lets
 * an app appear under Settings > Lock screen > Widgets on One UI devices (and optionally on
 * the Always-On-Display). This is not a published Google/Samsung API — Samsung hasn't
 * documented or guaranteed it, it may not appear on every One UI version, and it can change
 * or stop working in a future update without notice. It's included here as a best-effort
 * extra on top of the fully-supported home-screen widget, not a guarantee.
 */
class FaceWidgetReceiver : BroadcastReceiver() {

    companion object {
        private const val ACTION_REQUEST = "com.samsung.android.intent.action.REQUEST_SERVICEBOX_REMOTEVIEWS"
        private const val ACTION_RESPONSE = "com.samsung.android.intent.action.RESPONSE_SERVICEBOX_REMOTEVIEWS"
        private const val PAGE_ID = "clockface_widget"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != ACTION_REQUEST) return

        val pageId = intent.getStringExtra("pageId") ?: PAGE_ID
        val cal = Calendar.getInstance()
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        val dateFormat = SimpleDateFormat("EEE, dd MMM", Locale.getDefault())

        val lockViews = RemoteViews(context.packageName, R.layout.face_widget_lock).apply {
            setTextViewText(R.id.face_widget_time, timeFormat.format(cal.time))
            setTextViewText(R.id.face_widget_date, dateFormat.format(cal.time).uppercase(Locale.getDefault()))
        }
        val aodViews = RemoteViews(context.packageName, R.layout.face_widget_aod).apply {
            setTextViewText(R.id.face_widget_time, timeFormat.format(cal.time))
            setTextViewText(R.id.face_widget_date, dateFormat.format(cal.time).uppercase(Locale.getDefault()))
        }

        val response = Intent(ACTION_RESPONSE).apply {
            setPackage("com.android.systemui")
            putExtra("package", context.packageName)
            putExtra("pageId", pageId)
            putExtra("show", true)
            putExtra("origin", lockViews)
            putExtra("aod", aodViews)
        }
        context.sendBroadcast(response)
    }
}
