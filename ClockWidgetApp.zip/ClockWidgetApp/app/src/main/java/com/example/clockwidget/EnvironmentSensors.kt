package com.example.clockwidget

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

/**
 * Best-effort reader for the device's built-in ambient-temperature and relative-humidity
 * sensors, used by the "LCD Weather Station" digital face. Most phones don't have these
 * sensors — in that case the widget just shows "--" for those two fields instead of failing.
 *
 * Registered lazily, once per process, and kept passively listening at the system's default
 * rate so a fresh-ish value is already cached whenever the widget redraws (no blocking reads
 * on the widget-update path).
 */
object EnvironmentSensors {

    @Volatile private var lastTempCelsius: Float? = null
    @Volatile private var lastHumidityPct: Float? = null
    private var started = false

    @Synchronized
    fun ensureStarted(context: Context) {
        if (started) return
        started = true
        try {
            val appContext = context.applicationContext
            val sensorManager = appContext.getSystemService(Context.SENSOR_SERVICE) as? SensorManager ?: return

            val tempSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)
            val humiditySensor = sensorManager.getDefaultSensor(Sensor.TYPE_RELATIVE_HUMIDITY)

            val listener = object : SensorEventListener {
                override fun onSensorChanged(event: SensorEvent) {
                    when (event.sensor.type) {
                        Sensor.TYPE_AMBIENT_TEMPERATURE -> lastTempCelsius = event.values.getOrNull(0)
                        Sensor.TYPE_RELATIVE_HUMIDITY -> lastHumidityPct = event.values.getOrNull(0)
                    }
                }
                override fun onAccuracyChanged(sensor: Sensor, accuracy: Int) {}
            }

            tempSensor?.let { sensorManager.registerListener(listener, it, SensorManager.SENSOR_DELAY_NORMAL) }
            humiditySensor?.let { sensorManager.registerListener(listener, it, SensorManager.SENSOR_DELAY_NORMAL) }
        } catch (_: Exception) {
            // No sensor hardware / no permission needed but just in case — fall back to "--".
        }
    }

    fun currentTempCelsius(): Float? = lastTempCelsius
    fun currentHumidityPct(): Float? = lastHumidityPct
}
