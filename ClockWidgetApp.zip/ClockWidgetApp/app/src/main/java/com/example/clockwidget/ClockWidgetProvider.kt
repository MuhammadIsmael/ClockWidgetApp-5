package com.example.clockwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.text.format.DateFormat
import android.widget.RemoteViews
import java.util.Calendar

class ClockWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_TICK = "com.example.clockwidget.ACTION_TICK"
        private const val REQUEST_CODE = 1001

        // Bitmap sizes for the two clock faces. Kept small on purpose: these bitmaps travel
        // through Binder IPC to the launcher process on every tick, and a fast tick rate
        // combined with oversized bitmaps is what was overflowing the IPC transaction buffer
        // and crashing the widget ("Clock Widget keeps stopping"). ImageView's fitCenter
        // scaling means these still look sharp at normal widget sizes.
        private const val ANALOG_BITMAP_PX = 200
        private const val DIGITAL_BITMAP_W = 240
        private const val DIGITAL_BITMAP_H = 140

        fun updateAllWidgets(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(
                android.content.ComponentName(context, ClockWidgetProvider::class.java)
            )
            for (id in ids) {
                // Guarded per-widget: one bad frame (e.g. a Binder TransactionTooLargeException
                // if the host is briefly under memory pressure) must not take down every other
                // widget instance or crash-loop the whole app — skip that one id and keep going.
                try {
                    updateWidget(context, mgr, id)
                } catch (_: Exception) {
                }
            }
        }

        /**
         * Renders and pushes one widget instance's RemoteViews. Callers on the tick chain
         * (onUpdate/onReceive/updateAllWidgets) already catch exceptions from this, but
         * ClockWidgetConfigureActivity calls it directly on first setup, so this function
         * also guards its own IPC call — a failed updateAppWidget() here must not crash the
         * configure screen or leave the widget stuck on "Clock Widget keeps stopping".
         */
        fun updateWidget(context: Context, mgr: AppWidgetManager, widgetId: Int) {
            val cal = Calendar.getInstance()
            val views = RemoteViews(context.packageName, R.layout.clock_widget)
            val is24 = DateFormat.is24HourFormat(context)

            // Analog clock bitmap, using whichever face style this widget was configured with.
            // Kept modest in size (see ANALOG_BITMAP_PX) — RemoteViews ships bitmaps to the
            // launcher process over Binder IPC, which has a shared ~1MB transaction budget
            // per process. Oversized bitmaps sent on a fast tick can blow that budget and
            // crash the widget host with a TransactionTooLargeException.
            val style = WidgetPrefs.loadStyle(context, widgetId)
            val analogBmp = AnalogClockRenderer.render(ANALOG_BITMAP_PX, cal, style)
            views.setImageViewBitmap(R.id.analog_clock_image, analogBmp)

            // Digital clock bitmap, using whichever digital style this widget was configured
            // with. The "LCD Weather Station" style also wants ambient temperature/humidity,
            // which is a best-effort sensor read (many phones lack these sensors, so it just
            // falls back to "--" when unavailable).
            EnvironmentSensors.ensureStarted(context)
            val digitalStyle = WidgetPrefs.loadDigitalStyle(context, widgetId)
            val digitalBmp = DigitalClockRenderer.render(
                width = DIGITAL_BITMAP_W, height = DIGITAL_BITMAP_H, cal = cal, style = digitalStyle, is24Hour = is24,
                tempCelsius = EnvironmentSensors.currentTempCelsius(),
                humidityPct = EnvironmentSensors.currentHumidityPct()
            )
            views.setImageViewBitmap(R.id.digital_clock_image, digitalBmp)

            // Show/hide each half depending on the widget "type" (Both / Analog only / Digital only)
            val type = WidgetPrefs.loadType(context, widgetId)
            views.setViewVisibility(
                R.id.analog_clock_image,
                if (type == ClockType.DIGITAL_ONLY) android.view.View.GONE else android.view.View.VISIBLE
            )
            views.setViewVisibility(
                R.id.digital_clock_image,
                if (type == ClockType.ANALOG_ONLY) android.view.View.GONE else android.view.View.VISIBLE
            )

            // Tapping anywhere on the widget opens the face/style picker for THIS widget
            // instance, so the design can be changed anytime, not just when the widget is
            // first added. (There's no separate gear icon anymore — the whole widget is the
            // button.)
            val configIntent = Intent(context, ClockWidgetConfigureActivity::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val configPendingIntent = android.app.PendingIntent.getActivity(
                context, widgetId, configIntent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, configPendingIntent)

            try {
                mgr.updateAppWidget(widgetId, views)
            } catch (_: Exception) {
                // Binder transaction failed (e.g. TransactionTooLargeException). Skip this
                // frame rather than propagate — the next tick retries, and letting this throw
                // is what produces the "Clock Widget keeps stopping" dialog.
            }
        }

        /**
         * Schedules the next tick so the second hand and digital seconds stay live. Ticking
         * every 500ms (instead of once a second) gives a noticeably smoother analog second
         * hand — the fractional-second angle math lives in AnalogClockRenderer — without
         * pushing update frequency and bitmap payload high enough to overflow the widget
         * host's IPC transaction buffer. A prior attempt at 250ms reintroduced exactly that
         * crash ("Clock Widget keeps stopping" / TransactionTooLargeException), so 500ms is
         * the floor here — don't lower it without also shrinking ANALOG_BITMAP_PX/
         * DIGITAL_BITMAP_W/H to compensate. If you'd rather save battery and accept a
         * ticking (non-sweep) second hand, raise TICK_INTERVAL_MS back to 1000L.
         */
        private const val TICK_INTERVAL_MS = 500L

        fun scheduleNextTick(context: Context) {
            val intent = Intent(context, ClockWidgetProvider::class.java).apply {
                action = ACTION_TICK
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context, REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val triggerAt = SystemClock.elapsedRealtime() + TICK_INTERVAL_MS
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pendingIntent
            )
        }

        fun cancelTick(context: Context) {
            val intent = Intent(context, ClockWidgetProvider::class.java).apply {
                action = ACTION_TICK
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context, REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.cancel(pendingIntent)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        // Note: for a freshly-added widget with a configure Activity, the Activity itself calls
        // updateWidget() once the user confirms a style — onUpdate mainly matters for reboots/
        // periodic refresh of already-configured widgets, which is what this covers.
        try {
            updateAllWidgets(context)
        } catch (_: Exception) {
            // Don't let a bad frame prevent the tick chain from (re)starting below.
        }
        scheduleNextTick(context)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            WidgetPrefs.deleteAll(context, id)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TICK,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED -> {
                // Guarded: this runs on every tick, so any unexpected exception here (a bad
                // sensor reading, a transient IPC hiccup, etc.) must not be allowed to
                // propagate and crash-loop the widget — better to skip a frame and keep the
                // tick chain alive than to show "Clock Widget keeps stopping".
                try {
                    updateAllWidgets(context)
                } catch (_: Exception) {
                    // Skip this frame; the next tick will retry.
                }
                scheduleNextTick(context)
            }
        }
    }

    override fun onEnabled(context: Context) {
        scheduleNextTick(context)
    }

    override fun onDisabled(context: Context) {
        cancelTick(context)
    }
}
