package com.example.clockwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.text.format.DateFormat
import android.widget.RemoteViews
import java.util.Calendar

class ClockWidgetProvider : AppWidgetProvider() {

    companion object {
        const val ACTION_TICK = "com.example.clockwidget.ACTION_TICK"
        private const val REQUEST_CODE = 1001

        // Bitmap sizes for the two clock faces. Kept small on purpose: these bitmaps travel
        // through Binder IPC to the launcher process on every tick, and a fast tick rate
        // combined with oversized bitmaps is what was overflowing the IPC transaction buffer
        // and crashing the widget ("Clock Widget keeps stopping"). ImageView's fitCenter
        // scaling means these still look sharp at normal widget sizes.
        private const val ANALOG_BITMAP_PX = 200
        private const val DIGITAL_BITMAP_W = 240
        private const val DIGITAL_BITMAP_H = 140

        fun updateAllWidgets(context: Context) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(
                android.content.ComponentName(context, ClockWidgetProvider::class.java)
            )
            for (id in ids) {
                updateWidget(context, mgr, id)
            }
        }

        fun updateWidget(context: Context, mgr: AppWidgetManager, widgetId: Int) {
            val cal = Calendar.getInstance()
            val views = RemoteViews(context.packageName, R.layout.clock_widget)
            val is24 = DateFormat.is24HourFormat(context)

            // Analog clock bitmap, using whichever face style this widget was configured with.
            // Kept modest in size (see ANALOG_BITMAP_PX) — RemoteViews ships bitmaps to the
            // launcher process over Binder IPC, which has a shared ~1MB transaction budget
            // per process. Oversized bitmaps sent on a fast tick can blow that budget and
            // crash the widget host with a TransactionTooLargeException.
            val style = WidgetPrefs.loadStyle(context, widgetId)
            val analogBmp = AnalogClockRenderer.render(ANALOG_BITMAP_PX, cal, style)
            views.setImageViewBitmap(R.id.analog_clock_image, analogBmp)

            // Digital clock bitmap, using whichever digital style this widget was configured
            // with. The "LCD Weather Station" style also wants ambient temperature/humidity,
            // which is a best-effort sensor read (many phones lack these sensors, so it just
            // falls back to "--" when unavailable).
            EnvironmentSensors.ensureStarted(context)
            val digitalStyle = WidgetPrefs.loadDigitalStyle(context, widgetId)
            val digitalBmp = DigitalClockRenderer.render(
                width = DIGITAL_BITMAP_W, height = DIGITAL_BITMAP_H, cal = cal, style = digitalStyle, is24Hour = is24,
                tempCelsius = EnvironmentSensors.currentTempCelsius(),
                humidityPct = EnvironmentSensors.currentHumidityPct()
            )
            views.setImageViewBitmap(R.id.digital_clock_image, digitalBmp)

            // Show/hide each half depending on the widget "type" (Both / Analog only / Digital only)
            val type = WidgetPrefs.loadType(context, widgetId)
            views.setViewVisibility(
                R.id.analog_clock_image,
                if (type == ClockType.DIGITAL_ONLY) android.view.View.GONE else android.view.View.VISIBLE
            )
            views.setViewVisibility(
                R.id.digital_clock_image,
                if (type == ClockType.ANALOG_ONLY) android.view.View.GONE else android.view.View.VISIBLE
            )

            // Tapping anywhere on the widget opens the face/style picker for THIS widget
            // instance, so the design can be changed anytime, not just when the widget is
            // first added. (There's no separate gear icon anymore — the whole widget is the
            // button.)
            val configIntent = Intent(context, ClockWidgetConfigureActivity::class.java).apply {
                putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            }
            val configPendingIntent = android.app.PendingIntent.getActivity(
                context, widgetId, configIntent,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, configPendingIntent)

            mgr.updateAppWidget(widgetId, views)
        }

        /**
         * Schedules the next tick so the second hand and digital seconds stay live. Ticking
         * every 250ms (instead of once a second) gives a noticeably smoother analog second
         * hand — the fractional-second angle math lives in AnalogClockRenderer — while
         * staying well under the payload that overflowed the widget host's IPC transaction
         * buffer before (that combination is what caused the crash-loop fixed in this
         * version): the analog bitmap is only 200x200 ARGB_8888 (~160KB raw, much less once
         * compressed for the Binder transaction), so four ticks a second is comfortably
         * inside the ~1MB-per-process budget. If you'd rather save battery and accept a
         * ticking (non-sweep) second hand, raise TICK_INTERVAL_MS back to 1000L.
         */
        private const val TICK_INTERVAL_MS = 250L

        fun scheduleNextTick(context: Context) {
            val intent = Intent(context, ClockWidgetProvider::class.java).apply {
                action = ACTION_TICK
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context, REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            val triggerAt = SystemClock.elapsedRealtime() + TICK_INTERVAL_MS
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.ELAPSED_REALTIME_WAKEUP, triggerAt, pendingIntent
            )
        }

        fun cancelTick(context: Context) {
            val intent = Intent(context, ClockWidgetProvider::class.java).apply {
                action = ACTION_TICK
            }
            val pendingIntent = PendingIntent.getBroadcast(
                context, REQUEST_CODE, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.cancel(pendingIntent)
        }
    }

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        // Note: for a freshly-added widget with a configure Activity, the Activity itself calls
        // updateWidget() once the user confirms a style — onUpdate mainly matters for reboots/
        // periodic refresh of already-configured widgets, which is what this covers.
        try {
            updateAllWidgets(context)
        } catch (_: Exception) {
            // Don't let a bad frame prevent the tick chain from (re)starting below.
        }
        scheduleNextTick(context)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            WidgetPrefs.deleteAll(context, id)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_TICK,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED -> {
                // Guarded: this runs on every tick, so any unexpected exception here (a bad
                // sensor reading, a transient IPC hiccup, etc.) must not be allowed to
                // propagate and crash-loop the widget — better to skip a frame and keep the
                // tick chain alive than to show "Clock Widget keeps stopping".
                try {
                    updateAllWidgets(context)
                } catch (_: Exception) {
                    // Skip this frame; the next tick will retry.
                }
                scheduleNextTick(context)
            }
        }
    }

    override fun onEnabled(context: Context) {
        scheduleNextTick(context)
    }

    override fun onDisabled(context: Context) {
        cancelTick(context)
    }
}
