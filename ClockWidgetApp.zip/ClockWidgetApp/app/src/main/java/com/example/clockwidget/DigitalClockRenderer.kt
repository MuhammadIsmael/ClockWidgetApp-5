package com.example.clockwidget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** The available digital clock face designs. */
enum class DigitalStyle(val displayName: String) {
    LED_GREEN("LED Green");

    companion object {
        fun fromName(name: String?): DigitalStyle =
            entries.firstOrNull { it.name == name } ?: LED_GREEN
    }
}

/**
 * Renders the digital half of the widget as a single bitmap (same approach as
 * [AnalogClockRenderer]), so switching styles is just a matter of picking a different
 * drawing routine.
 */
object DigitalClockRenderer {

    fun render(
        width: Int,
        height: Int,
        cal: Calendar,
        style: DigitalStyle,
        is24Hour: Boolean
    ): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        when (style) {
            DigitalStyle.LED_GREEN -> drawLedGreen(canvas, width, height, cal, is24Hour)
        }
        return bmp
    }

    /** Small preview swatch used in the style picker. */
    fun renderPreview(width: Int, height: Int, style: DigitalStyle): Bitmap {
        val demo = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 15)
            set(Calendar.MINUTE, 45)
            set(Calendar.SECOND, 30)
        }
        return render(width, height, demo, style, is24Hour = true)
    }

    // ---------------------------------------------------------------------
    // LED Green (original style): dark background, bold green digits, small
    // amber AM/PM, white date line underneath.
    // ---------------------------------------------------------------------
    private fun drawLedGreen(canvas: Canvas, width: Int, height: Int, cal: Calendar, is24Hour: Boolean) {
        val timeFormat = if (is24Hour) SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                          else SimpleDateFormat("hh:mm:ss", Locale.getDefault())
        val ampmFormat = SimpleDateFormat("a", Locale.getDefault())
        val dateFormat = SimpleDateFormat("EEE  dd.MM.yyyy", Locale.getDefault())

        val unit = height.toFloat()
        val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#39FF6A")
            textSize = unit * 0.30f
            typeface = Typeface.MONOSPACE
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val ampmPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFCC00")
            textSize = unit * 0.13f
            typeface = Typeface.MONOSPACE
            textAlign = Paint.Align.CENTER
        }
        val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = unit * 0.12f
            typeface = Typeface.MONOSPACE
            textAlign = Paint.Align.CENTER
        }

        val cx = width / 2f
        var y = height * 0.42f
        canvas.drawText(timeFormat.format(cal.time), cx, y, timePaint)

        if (!is24Hour) {
            y += unit * 0.16f
            canvas.drawText(ampmFormat.format(cal.time).uppercase(Locale.getDefault()), cx, y, ampmPaint)
        } else {
            y += unit * 0.02f
        }

        y += unit * 0.22f
        canvas.drawText(dateFormat.format(cal.time).uppercase(Locale.getDefault()), cx, y, datePaint)
    }

}
