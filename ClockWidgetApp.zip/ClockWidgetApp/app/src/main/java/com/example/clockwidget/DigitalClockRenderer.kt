package com.example.clockwidget

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/** The available digital clock face designs. */
enum class DigitalStyle(val displayName: String) {
    LED_GREEN("LED Green"),
    LCD_WEATHER("LCD Weather Station");

    companion object {
        fun fromName(name: String?): DigitalStyle =
            entries.firstOrNull { it.name == name } ?: LED_GREEN
    }
}

/**
 * Renders the digital half of the widget as a single bitmap (same approach as
 * [AnalogClockRenderer]), so switching styles is just a matter of picking a different
 * drawing routine.
 */
object DigitalClockRenderer {

    /**
     * @param tempCelsius   last-known ambient temperature in °C, or null if no sensor/reading
     *                      is available yet (shown as "--").
     * @param humidityPct   last-known relative humidity in %, or null (shown as "--").
     */
    fun render(
        width: Int,
        height: Int,
        cal: Calendar,
        style: DigitalStyle,
        is24Hour: Boolean,
        tempCelsius: Float?,
        humidityPct: Float?
    ): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        when (style) {
            DigitalStyle.LED_GREEN -> drawLedGreen(canvas, width, height, cal, is24Hour)
            DigitalStyle.LCD_WEATHER -> drawLcdWeather(canvas, width, height, cal, is24Hour, tempCelsius, humidityPct)
        }
        return bmp
    }

    /** Small preview swatch used in the style picker. */
    fun renderPreview(width: Int, height: Int, style: DigitalStyle): Bitmap {
        val demo = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 15)
            set(Calendar.MINUTE, 45)
            set(Calendar.SECOND, 30)
        }
        return render(width, height, demo, style, is24Hour = true, tempCelsius = 28.5f, humidityPct = 53f)
    }

    // ---------------------------------------------------------------------
    // LED Green (original style): dark background, bold green digits, small
    // amber AM/PM, white date line underneath.
    // ---------------------------------------------------------------------
    private fun drawLedGreen(canvas: Canvas, width: Int, height: Int, cal: Calendar, is24Hour: Boolean) {
        val timeFormat = if (is24Hour) SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                          else SimpleDateFormat("hh:mm:ss", Locale.getDefault())
        val ampmFormat = SimpleDateFormat("a", Locale.getDefault())
        val dateFormat = SimpleDateFormat("EEE  dd.MM.yyyy", Locale.getDefault())

        val unit = height.toFloat()
        val timePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#39FF6A")
            textSize = unit * 0.30f
            typeface = Typeface.MONOSPACE
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val ampmPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#FFCC00")
            textSize = unit * 0.13f
            typeface = Typeface.MONOSPACE
            textAlign = Paint.Align.CENTER
        }
        val datePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = unit * 0.12f
            typeface = Typeface.MONOSPACE
            textAlign = Paint.Align.CENTER
        }

        val cx = width / 2f
        var y = height * 0.42f
        canvas.drawText(timeFormat.format(cal.time), cx, y, timePaint)

        if (!is24Hour) {
            y += unit * 0.16f
            canvas.drawText(ampmFormat.format(cal.time).uppercase(Locale.getDefault()), cx, y, ampmPaint)
        } else {
            y += unit * 0.02f
        }

        y += unit * 0.22f
        canvas.drawText(dateFormat.format(cal.time).uppercase(Locale.getDefault()), cx, y, datePaint)
    }

    // ---------------------------------------------------------------------
    // LCD Weather Station (new style, matching the reference photo): light-gray
    // LCD panel, dark segment-style time with seconds in a smaller block, a
    // speaker + alarm icon in the corner, a divider line, and a temperature /
    // humidity row underneath.
    // ---------------------------------------------------------------------
    private fun drawLcdWeather(
        canvas: Canvas, width: Int, height: Int, cal: Calendar, is24Hour: Boolean,
        tempCelsius: Float?, humidityPct: Float?
    ) {
        val unit = height.toFloat()
        val panelRect = RectF(0f, 0f, width.toFloat(), height.toFloat())
        val cornerRadius = unit * 0.10f

        // Panel background + frame, echoing the dark bezel / light LCD look.
        val framePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#3A3A3A")
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(panelRect, cornerRadius, cornerRadius, framePaint)

        val inset = unit * 0.045f
        val screenRect = RectF(panelRect.left + inset, panelRect.top + inset, panelRect.right - inset, panelRect.bottom - inset)
        val screenPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E9EAE6")
            style = Paint.Style.FILL
        }
        canvas.drawRoundRect(screenRect, cornerRadius * 0.7f, cornerRadius * 0.7f, screenPaint)

        val digitColor = Color.parseColor("#26282B")
        val pad = screenRect.width() * 0.06f

        // Time, e.g. "15:45:30" — big HH:MM, smaller :SS like the reference photo.
        val timeFormat = if (is24Hour) SimpleDateFormat("HH:mm", Locale.getDefault())
                          else SimpleDateFormat("hh:mm", Locale.getDefault())
        val secFormat = SimpleDateFormat("ss", Locale.getDefault())

        val bigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = digitColor
            typeface = Typeface.MONOSPACE
            isFakeBoldText = true
            textSize = screenRect.height() * 0.40f
            textAlign = Paint.Align.LEFT
        }
        val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = digitColor
            typeface = Typeface.MONOSPACE
            isFakeBoldText = true
            textSize = screenRect.height() * 0.24f
            textAlign = Paint.Align.LEFT
        }

        val timeStr = timeFormat.format(cal.time)
        val secStr = secFormat.format(cal.time)
        val timeBaselineY = screenRect.top + screenRect.height() * 0.40f
        val timeX = screenRect.left + pad
        canvas.drawText(timeStr, timeX, timeBaselineY, bigPaint)

        val bigWidth = bigPaint.measureText(timeStr)
        val secX = timeX + bigWidth + pad * 0.6f
        val secBaselineY = timeBaselineY - screenRect.height() * 0.06f
        canvas.drawText(":$secStr", secX, secBaselineY, smallPaint)

        // Speaker + alarm icons, top-right corner.
        val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = digitColor
            style = Paint.Style.STROKE
            strokeWidth = screenRect.height() * 0.012f
            strokeCap = Paint.Cap.ROUND
        }
        val iconTopY = screenRect.top + screenRect.height() * 0.13f
        drawSpeakerIcon(canvas, screenRect.right - pad - screenRect.height() * 0.30f, iconTopY, screenRect.height() * 0.10f, iconPaint, digitColor)
        drawAlarmIcon(canvas, screenRect.right - pad - screenRect.height() * 0.08f, iconTopY, screenRect.height() * 0.09f, iconPaint)

        // Divider line.
        val dividerY = screenRect.top + screenRect.height() * 0.56f
        val dividerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = digitColor
            strokeWidth = screenRect.height() * 0.012f
            alpha = 200
        }
        canvas.drawLine(screenRect.left + pad, dividerY, screenRect.right - pad, dividerY, dividerPaint)

        // Bottom row: thermometer + temperature, water drop + humidity.
        val bottomTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = digitColor
            typeface = Typeface.MONOSPACE
            isFakeBoldText = true
            textSize = screenRect.height() * 0.24f
            textAlign = Paint.Align.LEFT
        }
        val unitTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = digitColor
            typeface = Typeface.MONOSPACE
            textSize = screenRect.height() * 0.12f
            textAlign = Paint.Align.LEFT
        }

        val bottomBaselineY = screenRect.bottom - screenRect.height() * 0.10f
        val iconSize = screenRect.height() * 0.11f

        var x = screenRect.left + pad
        drawThermometerIcon(canvas, x, bottomBaselineY - iconSize * 0.65f, iconSize, iconPaint)
        x += iconSize * 1.5f
        val tempStr = tempCelsius?.let { String.format(Locale.getDefault(), "%.1f", it) } ?: "--"
        canvas.drawText(tempStr, x, bottomBaselineY, bottomTextPaint)
        x += bottomTextPaint.measureText(tempStr) + pad * 0.2f
        canvas.drawText("\u00B0C", x, bottomBaselineY - screenRect.height() * 0.10f, unitTextPaint)

        val rightBlockX = screenRect.left + screenRect.width() * 0.58f
        x = rightBlockX
        drawWaterDropIcon(canvas, x, bottomBaselineY - iconSize * 0.65f, iconSize, digitColor)
        x += iconSize * 1.5f
        val humidityStr = humidityPct?.let { it.toInt().toString() } ?: "--"
        canvas.drawText(humidityStr, x, bottomBaselineY, bottomTextPaint)
        x += bottomTextPaint.measureText(humidityStr) + pad * 0.2f
        canvas.drawText("%", x, bottomBaselineY, unitTextPaint)
    }

    private fun drawSpeakerIcon(canvas: Canvas, cx: Float, cy: Float, r: Float, stroke: Paint, fillColor: Int) {
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fillColor; style = Paint.Style.FILL }
        canvas.drawCircle(cx - r * 0.9f, cy, r * 0.22f, fill)
        canvas.drawArc(RectF(cx - r * 0.3f, cy - r * 0.6f, cx + r * 0.5f, cy + r * 0.6f), -55f, 110f, false, stroke)
        canvas.drawArc(RectF(cx + r * 0.1f, cy - r * 1f, cx + r * 1.1f, cy + r * 1f), -45f, 90f, false, stroke)
    }

    private fun drawAlarmIcon(canvas: Canvas, cx: Float, cy: Float, r: Float, stroke: Paint) {
        canvas.drawCircle(cx, cy + r * 0.1f, r * 0.7f, stroke)
        // Bell "ears"
        canvas.drawLine(cx - r * 0.55f, cy - r * 0.55f, cx - r * 0.9f, cy - r * 1.0f, stroke)
        canvas.drawLine(cx + r * 0.55f, cy - r * 0.55f, cx + r * 0.9f, cy - r * 1.0f, stroke)
        // Clock hands inside
        canvas.drawLine(cx, cy + r * 0.1f, cx, cy - r * 0.25f, stroke)
        canvas.drawLine(cx, cy + r * 0.1f, cx + r * 0.3f, cy + r * 0.1f, stroke)
    }

    private fun drawThermometerIcon(canvas: Canvas, x: Float, y: Float, size: Float, stroke: Paint) {
        val stemW = size * 0.28f
        val stemTop = y - size * 0.9f
        val bulbCy = y + size * 0.55f
        val stemRect = RectF(x, stemTop, x + stemW, bulbCy)
        canvas.drawRoundRect(stemRect, stemW / 2, stemW / 2, stroke)
        canvas.drawCircle(x + stemW / 2, bulbCy, stemW * 0.85f, stroke)
    }

    private fun drawWaterDropIcon(canvas: Canvas, x: Float, y: Float, size: Float, color: Int) {
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { this.color = color; style = Paint.Style.STROKE; strokeWidth = size * 0.09f }
        val path = Path()
        val topX = x + size * 0.35f
        val topY = y - size * 0.7f
        val bottomY = y + size * 0.35f
        path.moveTo(topX, topY)
        path.quadTo(topX + size * 0.55f, bottomY - size * 0.25f, topX, bottomY)
        path.quadTo(topX - size * 0.55f, bottomY - size * 0.25f, topX, topY)
        path.close()
        canvas.drawPath(path, fill)
    }
}
