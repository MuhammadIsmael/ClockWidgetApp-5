package com.example.clockwidget

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.TextView

/**
 * Shown when a widget is first added, and reopened later via the widget's own gear icon
 * (or the system's long-press "Edit widget" on Android 12+). Lets the user pick which
 * clock type to show (analog+digital / analog only / digital only) and which face style
 * to use for the analog clock.
 */
class ClockWidgetConfigureActivity : Activity() {

    private var widgetId: Int = AppWidgetManager.INVALID_APPWIDGET_ID
    private var selectedStyle: ClockStyle = ClockStyle.CLASSIC_BLACK
    private var selectedType: ClockType = ClockType.BOTH
    private var selectedDigitalStyle: DigitalStyle = DigitalStyle.LED_GREEN
    private val styleRowViews = mutableMapOf<ClockStyle, LinearLayout>()
    private val typeRowViews = mutableMapOf<ClockType, LinearLayout>()
    private val digitalStyleRowViews = mutableMapOf<DigitalStyle, LinearLayout>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // If the user backs out without confirming, don't place a widget.
        setResult(Activity.RESULT_CANCELED)

        setContentView(R.layout.clock_widget_configure)

        widgetId = intent?.extras?.getInt(
            AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID
        ) ?: AppWidgetManager.INVALID_APPWIDGET_ID

        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }

        // If this widget already has settings saved (i.e. the user tapped the gear icon to
        // reconfigure an existing widget), preselect them instead of always defaulting.
        selectedStyle = WidgetPrefs.loadStyle(this, widgetId)
        selectedType = WidgetPrefs.loadType(this, widgetId)
        selectedDigitalStyle = WidgetPrefs.loadDigitalStyle(this, widgetId)

        buildTypeList()
        buildStyleList()
        buildDigitalStyleList()

        findViewById<Button>(R.id.confirm_button).setOnClickListener {
            WidgetPrefs.saveStyle(this, widgetId, selectedStyle)
            WidgetPrefs.saveType(this, widgetId, selectedType)
            WidgetPrefs.saveDigitalStyle(this, widgetId, selectedDigitalStyle)

            val appWidgetManager = AppWidgetManager.getInstance(this)
            ClockWidgetProvider.updateWidget(this, appWidgetManager, widgetId)
            // This is what actually starts (or restarts) the live tick loop — without it, a
            // freshly-added widget's second hand would render once and then sit frozen until
            // the next reboot/timezone change, since onUpdate() is never called for widgets
            // that have a configure Activity like this one.
            ClockWidgetProvider.scheduleNextTick(this)

            val resultValue = Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId)
            setResult(Activity.RESULT_OK, resultValue)
            finish()
        }
    }

    private fun buildTypeList() {
        val container = findViewById<LinearLayout>(R.id.type_list_container)
        val inflater = LayoutInflater.from(this)

        for (type in ClockType.entries) {
            val row = inflater.inflate(R.layout.clock_type_row, container, false) as LinearLayout
            val label = row.findViewById<TextView>(R.id.type_row_label)
            val radio = row.findViewById<RadioButton>(R.id.type_row_radio)

            label.text = type.displayName
            radio.isChecked = type == selectedType

            row.setOnClickListener { selectType(type) }

            typeRowViews[type] = row
            container.addView(row)
        }
    }

    private fun buildStyleList() {
        val container = findViewById<LinearLayout>(R.id.style_list_container)
        val inflater = LayoutInflater.from(this)

        for (style in ClockStyle.entries) {
            val row = inflater.inflate(R.layout.clock_style_row, container, false) as LinearLayout
            val preview = row.findViewById<ImageView>(R.id.row_preview)
            val label = row.findViewById<TextView>(R.id.row_label)
            val radio = row.findViewById<RadioButton>(R.id.row_radio)

            preview.setImageBitmap(AnalogClockRenderer.renderPreview(128, style))
            label.text = style.displayName
            radio.isChecked = style == selectedStyle

            row.setOnClickListener { selectStyle(style) }

            styleRowViews[style] = row
            container.addView(row)
        }
    }

    private fun selectStyle(style: ClockStyle) {
        selectedStyle = style
        for ((s, row) in styleRowViews) {
            row.findViewById<RadioButton>(R.id.row_radio).isChecked = (s == style)
        }
    }

    private fun buildDigitalStyleList() {
        val container = findViewById<LinearLayout>(R.id.digital_style_list_container)
        val inflater = LayoutInflater.from(this)

        for (style in DigitalStyle.entries) {
            val row = inflater.inflate(R.layout.clock_style_row, container, false) as LinearLayout
            val preview = row.findViewById<ImageView>(R.id.row_preview)
            val label = row.findViewById<TextView>(R.id.row_label)
            val radio = row.findViewById<RadioButton>(R.id.row_radio)

            preview.setImageBitmap(DigitalClockRenderer.renderPreview(96, 60, style))
            label.text = style.displayName
            radio.isChecked = style == selectedDigitalStyle

            row.setOnClickListener { selectDigitalStyle(style) }

            digitalStyleRowViews[style] = row
            container.addView(row)
        }
    }

    private fun selectDigitalStyle(style: DigitalStyle) {
        selectedDigitalStyle = style
        for ((s, row) in digitalStyleRowViews) {
            row.findViewById<RadioButton>(R.id.row_radio).isChecked = (s == style)
        }
    }

    private fun selectType(type: ClockType) {
        selectedType = type
        for ((t, row) in typeRowViews) {
            row.findViewById<RadioButton>(R.id.type_row_radio).isChecked = (t == type)
        }
    }
}
